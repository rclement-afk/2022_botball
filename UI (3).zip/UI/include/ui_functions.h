#define rotate_deg_factor -1.17
void move(int l_speed,int r_speed);
void gyro_drive(int speed,float time,int end);
void rotate(int deg);
int accel(int speed);
int dccel(int speed);
double bias;
double calibrate_gyro();
void a_cel();
void d_cel();
void Drive(int desired,int speed);
void drive_with_gyro(int speed, double time);
void turn_with_gyro(int speed, int deg, int frz);
void PID_gyro_drive(int speed, double time);