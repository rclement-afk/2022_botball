#include <kipr/wombat.h>
#include <math.h>
#include <UI.h>
#include <ui_functions.h>


void move(int l_speed,int r_speed){//basic moving function thats based off mav
    mav(cMR,r_speed);
    mav(cML,l_speed);
};

void gyro_drive(int speed,float time,int end){
    int theta=0,prev=0;
    float startTime = seconds();
    set_create_total_angle(0);
    accel(speed);
    while(1){
        theta=get_create_total_angle();
        //total_angle sometimes glitches out and this saves it
        if(theta>prev+10 || theta<prev-10){set_create_total_angle(prev);printf("\n=_=\n");theta=get_create_total_angle();}
        prev=theta;
        create_drive_direct(speed+(theta*15),speed+(theta*-15));
        if(seconds()-startTime>time){break;}
        msleep(15);
    }
    if(end){dccel(speed);}
}
void rotate(int deg){
    int fast=100;
    int speed,prev=0,theta=0;
    deg=deg*rotate_deg_factor;
    set_create_total_angle(0);
    while(theta>deg+1 || theta<deg-1){
        theta=get_create_total_angle();

        //total_angle sometimes glitches out and this saves it
        if(theta>prev+10 || theta<prev-10){set_create_total_angle(prev);printf("\n=_=\n");theta=get_create_total_angle();}
        
        prev=theta;
        speed=(10*(deg-theta))^4;
        if(speed> 	fast){speed=   fast;}
        if(speed<-1*fast){speed=-1*fast;}
        create_drive_direct(speed*-1,speed*1);
        msleep(15);
        //printf("%d ",theta);
    }
    printf("\n%d\n",(int)(get_create_total_angle()/rotate_deg_factor));
    create_drive_direct(0,0);
}
int accel(int speed){
    if(speed<75){create_drive_direct(speed,speed);return 0;}
    int m_speed,s_seconds=seconds();
    int per_sec=400;
    while((seconds()-s_seconds)*per_sec<speed){
        m_speed=(seconds()-s_seconds)*per_sec;
        create_drive_direct(m_speed,m_speed);
        msleep(15);
    }
    
    return 1;
}
int dccel(int speed){
    if(speed<75){create_drive_direct(0,0);return 0;}
	int per_sec=300,s_seconds=seconds();
    int m_speed=speed-((seconds()-s_seconds)*per_sec);
    while(m_speed>1){
        m_speed=speed-((seconds()-s_seconds)*per_sec);
        create_drive_direct(m_speed,m_speed);
        msleep(15);
    }
    create_drive_direct(0,0);
    return 1;
}
double bias;
double calibrate_gyro(){//gyro calibration through finding gyro setting it to zero then setting theta as that value
    int i = 0;
    double avg = 0;
    while( i < 50){
        avg += gyro_z();
        msleep(1);
        i++;
    }
    bias = avg / 50.0;
    printf("New Bias: %f\n", bias);
    return bias;
}
void a_cel(){
    float L_speed;
    float curr_time = seconds(); 
    float init_time = seconds();
    while( (curr_time - init_time) < .2 ){
        curr_time = seconds();   
        L_speed = 6.75 * ((curr_time - init_time) * 1000);
        move(L_speed,L_speed); 
    };
};

void de_cel(){
    cmpc(cML);
    cmpc(cMR);
    while(gmpc(cML) < 500){

        int R_speed = 2.4 * (500 - gmpc(cMR) + 150);
        int L_speed = 2.4 * (500 - gmpc(cML) + 150);
        move(L_speed,R_speed);

    };
    move(0,0);
};
void Drive(int desired,int speed){
    float add_fact = 1.920137e-16;
    float mult_fact = 0.00004470956;
    double theta = 0;
    float max_speed = 0;
    cmpc(cML);
    cmpc(cMR);
    if(desired > 0 ){
        a_cel(); 
        if(desired < speed){
            speed = desired;   
        }
        while( gmpc ( cML ) < ( desired - 500 )){
            if( speed > 0 ){
                motor( cMR,  (( speed - speed * (add_fact + mult_fact * theta))));
                motor( cML, (( speed + speed * (add_fact + mult_fact * theta))));
            }
            else{
                motor( cMR,  (( speed + speed * (add_fact + mult_fact * theta))));
                motor( cML,  (( speed - speed * (add_fact + mult_fact * theta))));
            }
            msleep(10);
            theta += ( gyro_z() - bias) * 10;
            (speed + speed * (add_fact + mult_fact * theta)) > max_speed ? max_speed=(speed + speed * (add_fact + mult_fact * theta)) : msleep(1);
        }
        if ( desired > 500 ){
            de_cel();
            printf("%f",max_speed);
            move(0,0);
        }
        else{
            move(0,0);
        }
    }
    else if (desired < 0){
        while( gmpc ( cML ) > desired ){
            if( speed > 0 ){
                motor( cMR,  (( speed - speed * (add_fact + mult_fact * theta))));
                motor( cML, (( speed + speed * (add_fact + mult_fact * theta))));
            }
            else{
                motor( cMR,  (( speed + speed * (add_fact + mult_fact * theta))));
                motor( cML,  (( speed - speed * (add_fact + mult_fact * theta))));
            }
            msleep(10);
            theta += ( gyro_z() - bias) * 10;
            (speed + speed * (add_fact + mult_fact * theta)) > max_speed ? max_speed=(speed + speed * (add_fact + mult_fact * theta)) : msleep(1);
        }   
    }
}


//////////////////////////////////////////////////////////////////
void drive_with_gyro(int speed, double time){//gyro using clock time not distance(much more inaccurate)
    double startTime = seconds();
    double theta = 0;
    while(seconds() - startTime < time){
        //calibrate_gyro();
        if (theta < 1000 && theta > -1000){
            mav(cMR, speed);
            mav(cML, speed);
        }
        else if (theta < 1000){
            mav(cMR, speed + 100);
            mav(cML, speed - 100);
        }
        else{
            mav(cMR, speed - 100);
            mav(cML, speed + 100);
        }
        msleep(10);
        theta += (gyro_z() - bias) * 10;
        printf("%f",theta);
    };
    move(0,0);
};
//////////////////////////////////////////////////////////////////
void turn_with_gyro(int speed, int deg, int frz){//turning using the gyro we use calibrate still to find zero then set theta to a know value instead of 0
    //frz is if wheel freezes when turning. 1 is yes
    double theta = 0;
    int targetTheta; 
    int turn;
    if(frz == 1){turn = 0;}else{turn = -1*speed;}
    switch(deg){
        case 45:
            targetTheta = c45;
            move(speed,turn);
            break;
        case 90:
            targetTheta = c90;
            move(speed,turn);
            break;
        case 180:
            targetTheta = c180;
            move(speed,turn);
            break;
        case -45:
            targetTheta = cm45;
            move(turn,speed);
            break;
        case -90:
            targetTheta = cm90;
            move(turn,speed);
            break;
        case -180:
            targetTheta = cm180;
            move(turn,speed);
            break;
        default:
            targetTheta = 0;
            break;
    }  
    while(theta < targetTheta){
        msleep(10);
        theta += abs(gyro_z() - bias) * 10;
        printf("Turn Gyro Z: %d\n",gyro_z());
    }
    move(0,0);
    msleep(50);
    
}

//////////////////////////////////////////////////////////////////
void PID_gyro_drive(int speed, double time){
    double startTime = seconds();
    double theta = 0;
    while((seconds() - startTime) < time){
        if(speed > 0){
            mav(cMR, (speed - (speed * (theta/100000))));            
            mav(cML, (speed + (speed * theta/100000)));
        }


        else{
            mav(cML, (speed - (speed * theta/100000)));            
            mav(cMR, (speed + (speed * (theta/100000))));
        }
        msleep(10);
        theta += (gyro_z() - bias) * 10;
    }
    move(0,0);
};
////////////////////////////////////////////////////////