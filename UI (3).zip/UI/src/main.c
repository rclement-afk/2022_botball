#include <kipr/wombat.h>
#include <UI.h>

int main()
{
    while(startup){button_press(); msleep(50);}
    printf("yippee");
    return 0;
}
