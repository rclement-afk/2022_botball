#include <math.h>
#include <kipr/wombat.h>
#include <ui_functions.h>
#include <UI.h>

//file written by Carleigh Wilcox
//follow all directions listed in comments.
//copy+paste this line of code to main.c:
/*
	while(startup){button_press(); msleep(50);}
*/
//comment the line out if you do not want to use the ui
//add your program functions after the line
//change the below variables to match your robot. if N/A, leave it as 9
int cML = 9; //left motor
int cMR = 9; //right motor
int cM = 9; //any extra motor
int cET = 9; //ET
int cET2 = 9; //2nd ET
int clIR = 9; //left IR
int crIR = 9; //right IR
int clight = 9; //light sensor
int extra1 = 9; //any extra analog 
int extra2 = 9; //any extra analog
int cS0 = 0; //0th servo
int cS1 = 1; //1st servo
int cS2 = 2; //2nd servo
int cS3 = 3; //3rd servo
int c45 = 9; //45 theta
int cm45 = 9; //-45 theta
int c90 = 9; //90 theta
int cm90 = 9; //-90 theta
int c180 = 9; //180 theta
int cm180 = 9; //-180 theta

//no touchy beyond this line \/
/////////////////



// NO TOUCHY \/

int serv_var = 9;
int gyro_ang = 9;
int theta_val = 0;
int connect = 0;
int c_speed = 100;
double c_time = 1000;
int device = 0;

int choice = 1; 
int startup = 1;
int mainm = 0;
int start = 0;
int diag = 0;
int motorm = 0;
int servom = 0;
int serv = 0;
int gyrom = 0;
int thetam = 0;
int test_period = 0;
int thetam2 = 0;
int sensors = 0;
int create = 0;
int c_sensors = 0;
int c_drive = 0;
int c_deg;

void stop_all(){

}

void button_press(){    
    while(choice > 0){boot();}
    while(mainm > 0){f_startup();}
    while(diag > 0){f_diag();}
    while(start > 0){f_start();}
    while(motorm > 0){f_motors();}
    while(servom > 0){f_servos();}
    while(serv > 0){servos();}
    while(gyrom > 0){f_gyro();}
    while(thetam > 0){f_theta();}
    while(test_period > 0){gyro_test();}
    while(thetam2 > 0){theta2();}
    while(sensors > 0){f_sensors();}
    while(create > 0){f_create();}
    while(c_sensors > 0){fc_sensors();}
    while(c_drive > 0){fc_drive();}
    while(c_deg > 0){change_deg();}
}
void boot(){
    choice++;
    if(choice == 2){
        extra_buttons_show();
        printf("A Button: Boot\n\nWarning: Before pressing the stop button or backing out of the program, make sure you END PROGRAM\n");
    }
    if(a_button()){
        while(a_button()){msleep(50);}
        choice = 0;
        mainm = 1;
        printf("\n\n\nBooting..\n\n\n");
    }
}
void f_startup(){
    mainm++;
    if(mainm == 2){
    	printf("\nA Button: Start Robot\nB Button: Diagnostics\nZ Button: End Program\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
        mainm = 0;
        start = 1;       
    } 
    if(b_button()){
        while(b_button()){msleep(50);}
        mainm = 0;
        diag = 1;
    } 
    if(z_button()){
    	while(z_button()){msleep(50);}
        printf("\nProgram Ended");
        choice = 0;
        start = 0;
        diag = 0;
        mainm = 0;
        motorm = 0;
        servom = 0;
        serv = 0;
        gyrom = 0;
        test_period = 0;
    	startup = 0;
    }
}

void f_start(){
    start++;
    if(start == 2){
    	printf("\nA Button: Light\nB Button: Start Now\nC Button: Countdown\nZ Button: Cancel\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
        int val;
        if(clight == 9){
        	printf("\nPlease change the value of your light sensor variable.\n");
            start = 0;
            mainm = 1;
        }
        val = analog(clight);
        while(val < 500 && clight != 9){    
            val = analog(clight); 
        	printf("\nCalibrating: %d",val);
            msleep(500);
            console_clear();
            if(val > 500){//function
                printf("\n\n\nStarting!\n\n\n");
            	startup = 0;
            }
            //function
   		 } 
    }
    if(b_button()){
        while(b_button()){msleep(50);}
		printf("\n\n\nStarting!\n\n\n");
        start = 0;
        startup = 0;
        //function
    } 
    if(c_button()){
        while(c_button()){msleep(50);}
        start = 0;
        startup = 0;
        int i = 1;
        printf("\n\n\n");
    	while(i < 4){
            printf("%d, ",i);
        	msleep(1000);
            i++;    
        }
        printf("\n\n\nStarting!\n\n\n");
        //function
    }
    if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
    	start = 0;
        mainm = 1;
    }
}

void f_diag(){
    diag++;
    if(diag == 2){
    	printf("\nA Button: Motors\nB Button: Servos\nC Button: Wallaby Gyroscope\nX Button: Sensors\nY Button: Create\nZ Button: Cancel\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
    	diag = 0;
        motorm = 1;
    }
    if(b_button()){
        while(b_button()){msleep(50);}
    	diag = 0;
        servom = 1;
    }
    if(c_button()){
    	diag = 0;
        device = 0;
        gyrom = 1;
        while(c_button()){msleep(50);}
    }
    if(x_button()){
    	while(x_button()){msleep(50);}
    	diag = 0;
        sensors = 1;
    }
    if(y_button()){
    	while(y_button()){msleep(50);}
        diag = 0;
        create = 1;
    }
     if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
    	diag = 0;
        mainm = 1;
    }
}
void f_motors(){
    motorm++;
    if(motorm == 2){
    	printf("\nA Button: Left Motor\nB Button: Right Motor\nC Button: Misc Motor\nX Button: Drive\nZ Button: Cancel\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
        if(cML != 9){
        	motors(cML, 1); 
        	motors(cML, -1);
        }else{
            printf("\nYour motor is not valid.\n");
        }
    }
    if(b_button()){
        while(b_button()){msleep(50);}
        if(cMR != 9){
        	motors(cMR, 1); 
        	motors(cMR, -1);
        }else{
            printf("\nYour motor is not valid.\n");
        }
    }
    if(c_button()){
        while(c_button()){msleep(50);}
        if(cM != 9){
        	motors(cM, 1); 
        	motors(cM, -1);
        }else{
            printf("\nYour motor is not valid.\n");
        }
    }
    if(x_button()){
        while(x_button()){msleep(50);}
        if(cML != 9 && cMR != 9){
        	device = 0;
            motorm = 0;
            c_drive = 1;
        }else{
            printf("\nYour motors are not valid.\n");
        }
        
    }
    if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
    	motorm = 0;
        diag = 1;
    }
}
void motors(int motor, int dir){
    if(motor != 9){
		printf("\n\n\nMotor Test In Progress: \n");
    	msleep(600);
    	cmpc(motor);
    	if(dir < 0){
    		while(gmpc(motor) > dir*600){
          		mav(motor,dir*200);
     		}
   		 }
    	if(dir > 0){
    		while(gmpc(motor) < dir*600){
          		mav(motor,dir*200);
     		}
   		 }
   		 printf("Motor: %d ticks",gmpc(motor));
    	 mav(motor,0);
    }
}
void f_servos(){
    servom++;
    if(servom == 2){
    	printf("\nA Button: 0th Servo\nB Button: 1st Servo\nC Button: 2nd Servo\nX Button: 3rd Servo\nZ Button: Cancel\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
        servom = 0;
        serv = 1;
        serv_var = 0;
    }
    if(b_button()){
        while(b_button()){msleep(50);}
        servom = 0;
        serv = 1;
        serv_var = 1;
    }
    if(c_button()){
        while(c_button()){msleep(50);}
        servom = 0;
        serv = 1;
        serv_var = 2;
    }
    if(x_button()){
        while(x_button()){msleep(50);}
        servom = 0;
        serv = 1;
        serv_var = 3;
    }
    if(z_button()){
    	while(z_button()){msleep(50);}
    	servom = 0;
        serv_var = 9;
        diag = 1;
    }
}
void servos(){
    serv++;
    if(serv == 2){
    	printf("\nA Button: Up 10\nB Button: Down 10\nC Button: Up 100\nX Button: Down 100\nZ Button: Cancel\n");
    }
    if(a_button()){
        while(a_button()){msleep(50);}
    	servo_move(serv_var,10);
        msleep(50);
    }
    if(b_button()){
        while(b_button()){msleep(50);}
    	servo_move(serv_var,-10);
        msleep(50);
    }
    if(c_button()){
        while(c_button()){msleep(50);}
    	servo_move(serv_var,100);
        msleep(50);
    }
    if(x_button()){
        while(x_button()){msleep(50);}
    	servo_move(serv_var,-100);
        msleep(50);
    }
	if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
        serv = 0;
        servom = 1;
    }
}
void servo_move(int servo, int pos){
    servo = serv_var;
	enable_servos();
    msleep(100);
    if(get_servo_position(servo)+pos > 2047){set_servo_position(servo,2047); return;}
    if(get_servo_position(servo)+pos < 0){set_servo_position(servo,0); return;}
    set_servo_position(servo,get_servo_position(servo) + pos);
    msleep(100);
    disable_servos();
    printf("Position: %d\n",get_servo_position(servo));
}

void f_gyro(){
    gyrom++;
    if(gyrom == 2){
    	printf("\nA Button: 45\nB Button: 90\nC Button: 180\nZ Button: Cancel\n");
    }
    if(a_button()){
        while(a_button()){msleep(50);}
        gyrom = 0;
        test_period = 1;
        gyro_ang = 45;
    }
    if(b_button()){
        while(b_button()){msleep(50);}
        gyrom = 0;
        test_period = 1;
        gyro_ang = 90;
    }
	if(c_button()){
        while(c_button()){msleep(50);}
    	gyrom = 0;
        test_period = 1;
        gyro_ang = 180;
    }
	if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
    	gyrom = 0;
        diag = 1;
    }
}

void gyro_test(){
    test_period++;
    if(test_period == 2){
        if(!device){
    		printf("\nA Button: Positive\nB Button: Negative\nC Button: Change Theta\nZ Button: Cancel\n");
        }
        if(device){
    		printf("\nA Button: Positive\nB Button: Negative\nC Button: Change Deg Factor\nZ Button: Cancel\n");
        }
    }
    	if(a_button()){
            while(a_button()){msleep(50);}
            printf("\nMoving, theta: %d\n",gyro_ang);
            if(!device){
        		turn_with_gyro(400,gyro_ang,0);
            }
            if(device){
        		rotate(gyro_ang);
            }
            msleep(1000);
        }
        if(b_button()){
            while(b_button()){msleep(50);}
            printf("\nMoving, theta: %d\n",-1*gyro_ang);
        	if(!device){
        		turn_with_gyro(400,-1*gyro_ang,0);
            }
            if(device){
        		rotate(-1*gyro_ang);
            }
            msleep(1000);
        }
       if(c_button()){
            while(c_button()){msleep(50);}
            test_period = 0;
            if(!device){
            	thetam = 1;
            }
           if(device){
           		//e
           }
        }
        if(z_button()){
    		while(z_button()){msleep(50);}
       		printf("\nCanceled\n");
            test_period = 0;
    		gyrom = 1;
    	}
}
void f_theta(){
    thetam++;
    if(thetam == 2){
    	printf("\nA Button: Positive Direction\nB Button: Negative Direction\nZ Button: Cancel\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
    	thetam = 0;
        thetam2 = 1;
    }
    if(b_button()){
        while(b_button()){msleep(50);}
    	thetam = 0;
        thetam2 = 1;
        gyro_ang *= -1;
    }
	if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
    	thetam = 0;
        test_period = 1;
    }
}
void theta2(){
    thetam2++;
    if(thetam2 == 2){
    	printf("\nA Button: Up 100\nB Button: Down 100\nC Button: Up 1000\nX Button: Down 1000\nZ Button: Cancel\n");
    }
	if(a_button()){
        while(a_button()){msleep(50);}
        theta_val = 100;
    	change_theta(theta_val);
        msleep(50);
    }
    if(b_button()){
        while(b_button()){msleep(50);}
        theta_val = -100;
    	change_theta(theta_val);
        msleep(50);
    }
    if(c_button()){
        while(c_button()){msleep(50);}
        theta_val = 1000;
    	change_theta(theta_val);
        msleep(50);
    }
    if(x_button()){
        while(x_button()){msleep(50);}
        theta_val = -1000;
    	change_theta(theta_val);
        msleep(50);
    }
	if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
    	thetam2 = 0;
        test_period = 1;
    }
}
void change_theta(int val){
    int *ang;
	switch(gyro_ang){
        case 45:{ang = &c45;}
        case -45:{ang = &cm45;}
        case 90:{ang = &c90;}
        case -90:{ang = &cm90;}
        case 180:{ang = &c180;}
        case -180:{ang = &cm180;}
    }
    *ang += theta_val;
    printf("\nTheta Value: %d\n",*ang);
}
void f_sensors(){
		printf("\nTesting Sensors:\n");
             int sensorsA[] = {cET,cET2,clIR,crIR,clight,extra1,extra2};
             int i = 0;
             while(i<7){
                if(sensorsA[i] != 9){
                     printf("Sensor %d: ",sensorsA[i]);
                     printf("%d\n",analog(sensorsA[i]));
               	}
                 	i++;
              }
            printf("\nZ Button: Cancel\n");
    		int j = 0;
    		while(j < 250){
            	msleep(1);
                j++;
                if(z_button()){
             		while(z_button()){msleep(50);}
            	 	printf("Sensor Test Concluded!\n");
             		sensors = 0;
            		diag = 1;       
         		}
            }
        	console_clear();
         if(z_button()){
             while(z_button()){msleep(50);}
             printf("Sensor Test Concluded!\n");
             sensors = 0;
            diag = 1;
                    
         }
}
void f_create(){
    create++;
    if(create== 2){
        int i = 0;
        if(!connect){printf("\nConnecting to create. Spam Z to cancel.\nCountdown: ");}
        while(i < 10 && connect == 0){
            i++;
            printf("%d, ",i);
            msleep(1);
            if(create_connect_once()){
            	//create_connect();
                printf("\nCreate connected!\n");
                connect = 1;
            }	
            if(z_button()){
                while(z_button()){msleep(50);}
            	create = 0;
                diag = 1;
                printf("\nConnection terminated\n");
                return;
            }
        }
        if(i >= 9 && connect == 0){
        	printf("\nCould not connect to create.\n");
            create = 0;
            diag = 1;
            return;
        }
        printf("\nA Button: Battery\nB Button: Sensors\nC Button: Gyro\nX Button: Battery Rundown\nY Button: Drive\nZ Button: Cancel\n");
    }
    if(x_button()){
    	while(x_button()){msleep(50);}
        rundown();
        /*
        create_full();
        create_drive_direct(1000,1000);
        msleep(60000);
        create_drive_direct(0,0);
        create_safe();
        msleep(500);
        printf("\nRundown Concluded\n");
        */
    }
    if(a_button()){
    	while(a_button()){msleep(50);}
        printf("\nCharge: %d\n",get_create_battery_charge());
        printf("Temp: %d\n",get_create_battery_temp());
    }
    if(b_button()){
    	while(b_button()){msleep(50);}
        create = 0;
        c_sensors = 1;
    }
    if(c_button()){
    	while(c_button()){msleep(50);}
        create = 0;
        device = 1;
        gyrom = 1;
    }
    if(y_button()){
    	while(y_button()){msleep(50);}
        create = 0;
        device = 1;
        c_drive = 1;
    }
    if(z_button()){
        while(z_button()){msleep(50);}
        printf("\nRundown canceled\n");
        create = 0;
   		diag = 1;
    }
}
void rundown(){
	printf("\nCounting Down. Press Z to cancel\n");
        int i = 1;
        int j = 0;
        printf("\n\n\n");
    	while(i < 11){
            j = 0;
            while(j < 5000){
            	j++;
                if(z_button()){
                   while(z_button()){msleep(50);}
                   printf("\nRundown canceled\n");
                   create = 1;
                   return;
                }
            }
            printf("%d, ",i);
            i++;    
        }
        printf("Start!");
    	create_full();
        create_drive_direct(500,500);
        msleep(60000);
        create_drive_direct(0,0);
        create_safe();
        msleep(500);
        printf("\nRundown Concluded\n");
        create = 1;
}
void fc_sensors(){
	printf("Testing Create Sensors:\n");
    printf("Distance: %d\n",get_create_distance());
    printf("L CLiff: %d\n",get_create_lcliff());
    printf("LF CLiff: %d\n",get_create_lfcliff());
    printf("R CLiff: %d\n",get_create_rcliff());
    printf("RF CLiff: %d\n",get_create_rfcliff());
    
    printf("Z Button: Cancel");
    		int j = 0;
    		while(j < 250){
            	msleep(1);
                j++;
                if(z_button()){
             		while(z_button()){msleep(50);}
            	 	printf("Sensor Test Concluded!\n");
             		c_sensors = 0;
            		create = 1;       
         		}
            }
        	console_clear();
         if(z_button()){
             while(z_button()){msleep(50);}
             printf("Sensor Test Concluded!\n");
             c_sensors = 0;
            create = 1;    
         }
}
void fc_drive(){
	c_drive++;
    if(c_drive == 2){
    	printf("\nA Button: Go\nB Button: Up Speed\nC Button: Down Speed\nX Button: Up Time\nY Button: Down Time\nZ Button: Cancel\n");
    }
    if(a_button()){
    	while(a_button()){msleep(50);}
        if(c_time > 0){
        	printf("Moving at %d ",c_speed);
        	printf("for %f seconds.\n",c_time/1000);
            device = 1;
        	drive();
        }
        else{
        	printf("\nPlease make sure time is > than 0.\n");
        }
    }
    if(b_button()){
    	while(b_button()){msleep(50);}
        c_speed += 50;
        printf("Speed: %d\n",c_speed);
    }
    if(c_button()){
    	while(c_button()){msleep(50);}
        c_speed -= 50;
        printf("Speed: %d\n",c_speed);
    }
    if(x_button()){
    	while(x_button()){msleep(50);}
        c_time += 200;
        printf("Time: %f\n",c_time);
    }
    if(y_button()){
    	while(y_button()){msleep(50);}
        c_time += -200;
        printf("Time: %f\n",c_time);
    }
    if(z_button()){
    	while(z_button()){msleep(50);}
       	printf("\nCanceled\n");
        c_drive = 0;
        if(device){
        	create = 1;
        }
        if(!device){
        	motorm = 1;
        }
    }
}
void drive(){
    //msleep(500);
    if(device){
    	create_drive_direct(c_speed, c_speed);
   	 	msleep(c_time);
    	create_drive_direct(0,0);
    }
	if(!device){
        cmpc(cML);
        cmpc(cMR);
    	mav(cML,c_speed);
        mav(cMR,c_speed);
        msleep(c_time);
        mav(cML,0);
        mav(cMR,0);
        printf("\nLeft Motor: %d ticks\n",gmpc(cML));
        printf("\nRight Motor: %d ticks\n",gmpc(cMR));
        ao();
    }
    printf("\nA Button: Go\nB Button: Up Speed\nC Button: Down Speed\nX Button: Up Time\nY Button: Down Time\nZ Button: Cancel\n");
}
void change_deg(){

}