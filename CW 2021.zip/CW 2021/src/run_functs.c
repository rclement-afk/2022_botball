#include <kipr/botball.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/functions.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/consts.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/timer.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/threads.h>
#include </home/root/Documents/KISS/Default User/CW 2021/include/run_functs.h>
void god_start(){
  while(analog(4) > 200){
    msleep(50);
  }
  calibrate_gyro();
  thread_starting_pos();
  return plow();
}
void servo_start(){
  int startup;
  startup = get_servo_position(arm);
  slow_servo(arm,startup+5,1);
  msleep(3);
  startup = get_servo_position(claw);
  slow_servo(claw,startup+5,1);
  msleep(3);
}
void plow(){
    PID_gyro_drive(300,1.1);
    Drive(2400,40);
    square_up(2,400);
    slow_servo(arm,300,1);
    Drive(13400,60);
    PID_gyro_drive(-400,2);
    slow_servo(claw, claw_min,1);
    turn_with_gyro(400,-45);
    PID_gyro_drive(600,2);
    turn_with_gyro(400,-45);
    PID_gyro_drive(650,3);
    square_up(1,400);
    turn_with_gyro(400, -90);
    Drive(13300,60);
    turn_with_gyro(400,-45);
    PID_gyro_drive(600,5);
}
void ring_pickup(int dist, int arm_pos, int slack){
    Drive(-1*dist,30);
    slow_servo(claw,claw_max,1);
    slow_servo(arm,arm_pos,1);  //pickup
    slow_servo(claw, claw_min+slack,1);
    slow_servo(arm,arm_max,1);
    Drive(dist,30);
    
    PID_gyro_drive(500,3);
    slow_servo(claw,claw_max,1); //release 
    PID_gyro_drive(-500,3);
}
void grab_rings(){
    
    //UNFINISHED 
    
    //slow_servo(arm,arm_max,1);
    //slow_servo(arm,400,1);  //grab rings
   // slow_servo(claw, 150, 1);
   
   // printf("%d",gmpc(ML)); //6739
   // slow_servo(claw, claw_max-300, 1);
    //PID_gyro_drive(-300,1);
    //slow_servo(claw,claw_max,1);

    
   // slow_servo(claw,claw_max-500,1);
    
    
    /*
    square_up(2,450);
    slow_servo(arm,arm_max,1);
    Drive(2400,60);
    
    PID_gyro_drive(500,2.5);
    slow_servo(claw,claw_min,1);  //knock off tennis ball
    PID_gyro_drive(500,1);  //push rings forward
    slow_servo(claw,claw_max,1);
    PID_gyro_drive(-500,3.3);
    
    //speed, dist, time, arm_pos, slack
    ring_pickup(0,800,50);
    ring_pickup(50,750,100);
    ring_pickup(100,650,150);
    ring_pickup(150,550,250);
    ring_pickup(200,450,350);
   
    slow_servo(claw,claw_max,1);
    Drive(200,60);
    slow_servo(arm,450,1);  //grab base
    slow_servo(claw,claw_min,1);
    
    return shovel();
    */
    
    /*
    slow_servo(claw, claw_max, 1);
    slow_servo(arm, 385, 1);
    PID_gyro_drive(-200,0.9);
    slow_servo(claw, 200, 1);
    slow_servo(arm, arm_max, 1);
    slow_servo(claw, claw_max, 1);
    slow_servo(arm, 305, 1);
    PID_gyro_drive(100,2.5);
    slow_servo(claw, 200, 1);
    slow_servo(arm, arm_max, 1);
    slow_servo(claw, claw_max, 1);
    */
}
void shovel(){
  turn_with_gyro(400,180);
  PID_gyro_drive(500,4);
  square_up(1,400);
  turn_with_gyro(400,90);
  Drive(5000,60);
  turn_with_gyro(400,90);
  square_up(1,400);
  turn_with_gyro(400,90);
  
  
  Drive(10000,60);
}


/*
red: 3 
orange: 3 5/8
yellow: 3 7/8
green: 4 1/8
blue: 4 4/8
*/