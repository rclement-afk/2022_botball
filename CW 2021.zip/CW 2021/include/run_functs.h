//run functs
void god_start();
void servo_start();
void plow();
void ring_pickup(int dist, int arm_pos, int slack);
void grab_rings();
void shovel();