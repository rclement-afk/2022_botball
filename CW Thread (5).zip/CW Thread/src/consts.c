#include </home/root/Documents/KISS/Default User/CW Clone/include/consts.h>
int ML = 2;
int MR = 1;
int arm = 3;
int shifter = 2;
int claw = 0;
int rIR = 0;
int lIR = 2;
int fET = 4;
int light = 3;
int BR = 1;
int BL = 2;
//
int shifter_ver = 980;
int shifter_hor = 40;
int claw_max = 2000;
int claw_min = 600;
int arm_max = 250;
int arm_min = 2000; 
//
int analog_white = 160;
int analog_black = 2960;
int midpoint = 2000;
int target_theta_m30 = 150000;
int target_theta_m22 = 100000;
int target_theta_m40 = 230000; //170000
int target_theta_rings = 220000;
int target_theta_mrings = 220000;
int target_theta_45 = 265200; //275900
int target_theta_90 = 538000; //563800
int target_theta_180 = 1099900; //1135000
int target_theta_m45 = 266500; //275970
int target_theta_m90 = 541500; //562150
int target_theta_m180 = 1099900; //1135100