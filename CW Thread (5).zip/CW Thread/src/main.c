#include <kipr/botball.h>
#include <functions.h>
#include <consts.h>
#include <timer.h>
#include <run_functs.h>
#include <threads.h>
#include <clone_consts.h>
int main()
{
    god_start();
    //thread_destroy(servo_cntrl);
    return 0;
}
