//run vars
int base;
int dbase;
int ver;
int hor;
int mystery;
int Mmystery;
int white;
int black;
//run functs
int god_start();
void ring_loop(int lower);
void column_run();
int grab_rings();
int ring_stand_return();