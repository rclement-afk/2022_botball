float time_arr[6];
void reset_timer(int ind);
void reset_sys_timer();
float sys_timer();
int timer(int ind);